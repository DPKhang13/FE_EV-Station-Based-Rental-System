import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../../context/AuthContext";
import rentalStationService from "../../services/rentalStationService";
import maintenanceService from "../../services/maintenanceService";
import { orderService } from "../../services";
import api from "../../services/api";
import "./PopupNhanXe.css";

const PopupNhanChecking = ({ xe, onClose, onReload }) => {
  const { user } = useContext(AuthContext);

  const [orderInfo, setOrderInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);
  const [showConfirmPopup, setShowConfirmPopup] = useState(false);
  const [hasIncidents, setHasIncidents] = useState(false);
  const [receiveSuccess, setReceiveSuccess] = useState(false);

  const [severity, setSeverity] = useState(() => localStorage.getItem("nhanChecking_severity") || "");
  const [description, setDescription] = useState(() => localStorage.getItem("nhanChecking_description") || "");
  const [cost, setCost] = useState(() => localStorage.getItem("nhanChecking_cost") || "");

  // -------------------- Lấy dữ liệu đơn hàng --------------------
  const fetchOrderPreview = async () => {
    const orderId =
      xe?.order?.orderId ||
      xe?.order?.order_id ||
      xe?.orderId ||
      xe?.order_id;

    if (!orderId) {
      console.error("⚠️ Không có orderId hợp lệ:", xe);
      return;
    }

    try {
      setLoading(true);
      const res = await api.get(`/order/${orderId}/preview-return`);
      const data = res?.data ?? res;
      setOrderInfo(data);
      console.log("✅ [PopupNhanChecking] order preview:", data);
    } catch (err) {
      console.error("❌ Lỗi khi lấy preview-return:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (xe) fetchOrderPreview();
  }, [xe]);

  // -------------------- Auto refresh khi chờ thanh toán --------------------
  useEffect(() => {
    if (orderInfo?.status !== "AWAIT_FINAL") return;
    const intervalId = setInterval(fetchOrderPreview, 10000);
    return () => clearInterval(intervalId);
  }, [orderInfo?.status]);

  // -------------------- Lưu form tạm --------------------
  useEffect(() => {
    localStorage.setItem("nhanChecking_severity", severity);
    localStorage.setItem("nhanChecking_description", description);
    localStorage.setItem("nhanChecking_cost", cost);
  }, [severity, description, cost]);

  // -------------------- 🚨 Gửi báo cáo sự cố --------------------
  const handleReportIncident = async () => {
    if (!severity || !description.trim()) {
      alert("⚠️ Vui lòng chọn mức độ và nhập mô tả sự cố!");
      return;
    }

    const incidentData = {
      vehicleId: xe.id || xe.vehicleId,
      stationId: user?.stationId || 1,
      description,
      severity,
      status: "OPEN",
      occurredOn: new Date().toISOString().split("T")[0],
      cost: Number(cost) || 0,
      reportedBy: user?.userId || "unknown",
    };

    try {
      setSending(true);
      await api.post("/incidents/create", incidentData);
      alert("✅ Báo cáo sự cố đã được gửi thành công!");
      await fetchOrderPreview();
    } catch (error) {
      console.error("❌ Lỗi khi gửi báo cáo sự cố:", error);
      alert("Không thể gửi báo cáo sự cố!");
    } finally {
      setSending(false);
    }
  };

  // -------------------- 💰 Gửi yêu cầu thanh toán --------------------
  const handleRequestPayment = async () => {
    const orderId =
      xe?.order?.orderId ||
      xe?.order?.order_id ||
      xe?.orderId ||
      xe?.order_id;

    if (!orderId) return alert("⚠️ Không tìm thấy orderId hợp lệ!");

    try {
      setSending(true);
      const payload = {
        note: "Yêu cầu thanh toán sau kiểm tra xe",
        processedBy: user?.userId || "unknown",
      };

      const res = await orderService.return(orderId, payload);
      const data = res?.data ?? res;
      console.log("✅ [PopupNhanChecking] API return thành công:", data);

      alert("✅ Yêu cầu thanh toán khách hàng đã được gửi thành công!");
      setDone(true);
      await fetchOrderPreview();
    } catch (err) {
      console.error("❌ Lỗi khi gửi yêu cầu thanh toán:", err);
      alert("Không thể gửi yêu cầu thanh toán!");
    } finally {
      setSending(false);
    }
  };

  // -------------------- 🚗 Hoàn tất nhận xe --------------------
  const handleCompleteReceive = async () => {
    // 👉 nới điều kiện để tránh case status khác chữ COMPLETED
    if (!orderInfo || !["COMPLETED", "DONE", "PAID", "RETURNED"].includes(orderInfo.status)) {
      alert("⚠️ Đơn hàng chưa hoàn tất, không thể nhận xe!");
      return;
    }

    try {
      const today = new Date().toISOString().split("T")[0];
      const res = await maintenanceService.getAllIncidents();
      const incidents = Array.isArray(res) ? res : Array.isArray(res?.data) ? res.data : [];
      const relatedIncidents = incidents.filter(
        (i) =>
          Number(i.vehicleId) === Number(xe.id || xe.vehicleId) &&
          i.occurredOn?.startsWith(today)
      );

      setHasIncidents(relatedIncidents.length > 0);
      setShowConfirmPopup(true);
    } catch (err) {
      console.error("❌ Lỗi khi kiểm tra sự cố:", err);
      alert("Không thể kiểm tra sự cố!");
    }
  };

  // -------------------- 🧾 Xử lý lựa chọn từ popup --------------------
  const handleConfirmChoice = async (choice) => {
    setShowConfirmPopup(false);
    const newStatus = choice === "MAINTENANCE" ? "MAINTENANCE" : "AVAILABLE";

    try {
      await rentalStationService.updateVehicleStatus(xe.id || xe.vehicleId, {
        status: newStatus,
        battery: xe.pin || 100,
      });

      setReceiveSuccess(true);

      // ✅ Gọi callback reload thay vì reload trang
      setTimeout(() => {
        setReceiveSuccess(false);
        if (typeof onClose === "function") onClose();
        if (typeof onReload === "function") onReload();
      }, 1500);
    } catch (err) {
      console.error("❌ Lỗi khi cập nhật trạng thái xe:", err);
      alert("Không thể cập nhật trạng thái xe!");
    }
  };

  const handleClose = () => {
    if (typeof onClose === "function") onClose();
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content popup-maintenance">
        <h2>🔧 Nhận xe kiểm tra: {xe.ten}</h2>
        <p>Biển số: <strong>{xe.bienSo}</strong></p>
        <p>Hãng: <strong>{xe.hang}</strong></p>
        <p>Pin hiện tại: <strong>{xe.pin}%</strong></p>
        <hr />

        {loading ? (
          <p>Đang tải thông tin đơn hàng...</p>
        ) : orderInfo ? (
          <div className="order-info">
            <h3>📦 Thông tin đơn hàng</h3>
            <ul>
              <li><strong>Mã đơn:</strong> {orderInfo.orderId || orderInfo.order_id}</li>
              <li><strong>Xe ID:</strong> {orderInfo.vehicleId}</li>
              <li><strong>Trạng thái:</strong> {orderInfo.status}</li>
              <li><strong>Tổng tiền:</strong> {orderInfo.totalPrice?.toLocaleString()}₫</li>
              <li><strong>Còn lại phải trả:</strong> {orderInfo.remainingAmount?.toLocaleString()}₫</li>
            </ul>
          </div>
        ) : (
          <p>⚠️ Không tìm thấy thông tin đơn hàng!</p>
        )}

        <hr />

        {orderInfo?.status !== "AWAIT_FINAL" && orderInfo?.status !== "COMPLETED" && (
          <>
            <h3>📋 Báo cáo sự cố</h3>
            <select className="input-select" value={severity} onChange={(e) => setSeverity(e.target.value)}>
              <option value="">Chọn mức độ</option>
              <option value="LOW">Thấp</option>
              <option value="MEDIUM">Trung bình</option>
              <option value="HIGH">Cao</option>
            </select>

            <textarea
              className="input-textarea"
              placeholder="Mô tả sự cố..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            ></textarea>

            <input
              className="input-text"
              type="number"
              placeholder="Nhập chi phí (VNĐ)"
              value={cost}
              onChange={(e) => setCost(e.target.value)}
            />

            <button onClick={handleReportIncident} className="btn-pay" disabled={sending}>
              {sending ? "🔄 Đang gửi..." : "🚨 Gửi báo cáo sự cố"}
            </button>
          </>
        )}

        <hr />

        {!done ? (
          orderInfo?.status === "AWAIT_FINAL" ? (
            <button className="btn-check" disabled>
              ⏳ Vui lòng chờ khách hàng thanh toán...
            </button>
          ) : orderInfo?.status === "COMPLETED" ? (
            <button className="btn-check" disabled style={{ backgroundColor: "#28a745" }}>
              ✅ Đã thanh toán thành công
            </button>
          ) : (
            <button onClick={handleRequestPayment} className="btn-check" disabled={sending}>
              Gửi yêu cầu thanh toán khách hàng
            </button>
          )
        ) : (
          <p style={{ color: "green" }}>✅ Yêu cầu thanh toán đã được gửi thành công.</p>
        )}

        <hr />

        <div className="popup-buttons">
          {["COMPLETED", "DONE", "PAID", "RETURNED"].includes(orderInfo?.status) && (
            <button
              onClick={handleCompleteReceive}
              className="btn-confirm"
              style={{ backgroundColor: "#007bff", color: "#fff" }}
            >
              🚗 Hoàn tất nhận xe
            </button>
          )}
          <button onClick={handleClose} className="btn-cancel">
            Đóng
          </button>
        </div>
      </div>

      {/* Popup xác nhận */}
      {orderInfo && showConfirmPopup && (
        <div className="confirm-overlay">
          <div className="confirm-box">
            <h3>Hoàn tất nhận xe</h3>
            <p>
              {hasIncidents
                ? "Xe có sự cố hôm nay. Bạn muốn chuyển xe sang trạng thái nào?"
                : "Xe không có sự cố. Bạn muốn chuyển xe sang trạng thái nào?"}
            </p>
            <div className="confirm-actions">
              {hasIncidents && (
                <button
                  className="btn-maintenance"
                  onClick={() => handleConfirmChoice("MAINTENANCE")}
                >
                  Bảo trì
                </button>
              )}
              <button
                className="btn-available"
                onClick={() => handleConfirmChoice("AVAILABLE")}
              >
                Có sẵn
              </button>
              <button
                className="btn-cancel-popup"
                onClick={() => setShowConfirmPopup(false)}
              >
                ❌ Hủy
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Popup thành công */}
      {receiveSuccess && (
        <div className="confirm-overlay">
          <div className="confirm-box" style={{ borderTop: "6px solid #28a745" }}>
            <h3 style={{ color: "#28a745" }}>✅ Đã nhận xe thành công!</h3>
            <p>Trang sẽ tự cập nhật sau giây lát...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default PopupNhanChecking;
