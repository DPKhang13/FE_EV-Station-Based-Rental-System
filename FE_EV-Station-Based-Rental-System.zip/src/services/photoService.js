const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api';

// 👉 đặt hàm này lên đầu
const getAuthHeaders = () => {
  const token = localStorage.getItem('authToken');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const uploadForm = async (path, file, userId) => {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('userId', userId);

  const res = await fetch(`${API_BASE_URL}/${path}`, {
    method: 'POST',
    headers: { ...getAuthHeaders() },
    body: fd,
    credentials: 'include',
  });

  if (!res.ok) throw new Error('Upload failed');
  return await res.json();
};

const photoService = {
  uploadIdCard: (file, userId) => uploadForm('upload/id-card', file, userId),
  uploadDriverLicense: (file, userId) => uploadForm('upload/driver-license', file, userId),
};

export default photoService;
