// pages/ThanhToanPage.jsx
import React, { useState, useEffect } from "react";
import transactionService from "../services/transactionService";
import "./ThanhToanPage.css";

// 🪙 Định dạng tiền VND
const formatVND = (n) =>
  (Number(n) || 0).toLocaleString("vi-VN", {
    style: "currency",
    currency: "VND",
  });

// 🔤 Dịch trạng thái sang tiếng Việt
const translateStatus = (status = "") => {
  const map = {
    SUCCESS: "Thành công",
    FAILED: "Thất bại",
    PENDING: "Đang xử lý",
  };
  return map[status.toUpperCase()] || "Không xác định";
};

// 🔤 Dịch loại giao dịch sang tiếng Việt
const translateType = (type = "") => {
  const map = {
    DEPOSIT: "Đã cọc tiền",
    WITHDRAW: "Rút tiền",
    RENTAL_PAYMENT: "Thanh toán thuê xe",
    REFUND: "Hoàn tiền",
    TOP_UP: "Nạp tài khoản",
  };
  return map[type.toUpperCase()] || "Khác";
};

const ThanhToanPage = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [phone, setPhone] = useState("");

  // 🚀 Lấy toàn bộ giao dịch khi mở trang
  useEffect(() => {
    fetchTransactions();
  }, []);

  // 🔁 Hàm tải danh sách giao dịch
  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const res = await transactionService.getAllTransactions();
      const data = Array.isArray(res?.data) ? res.data : res;
      setTransactions(data || []);
    } catch (err) {
      console.error("❌ Lỗi tải giao dịch:", err);
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  };

  // 🔍 Tra cứu theo số điện thoại
  const handleSearch = async () => {
    if (!phone.trim()) {
      setError("Vui lòng nhập số điện thoại khách hàng!");
      return;
    }
    setError("");
    try {
      setLoading(true);
      const res = await transactionService.searchByUserId(phone);
      setTransactions(Array.isArray(res) ? res : []);
    } catch (err) {
      console.error("❌ Lỗi tìm kiếm:", err);
      setError("Không tìm thấy dữ liệu giao dịch!");
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      {/* 🔍 Form tìm kiếm */}
      <div className="search-boxs">
        <h2>Tra cứu lịch sử giao dịch</h2>
        <div className="search-form">
          <input
            type="text"
            placeholder="Nhập số điện thoại khách hàng"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
          <button onClick={handleSearch} disabled={loading}>
            {loading ? "Đang tìm..." : "Tìm kiếm"}
          </button>
        </div>
        {error && <p className="error">{error}</p>}
      </div>

      {/* 📊 Bảng kết quả */}
      {loading && <p className="loading">Đang tải dữ liệu...</p>}

      <table className="transaction-table">
        <thead>
          <tr>
            <th>Mã giao dịch</th>
            <th>Số tiền</th>
            <th>Trạng thái</th>
            <th>Loại</th>
            <th>Thời gian</th>
          </tr>
        </thead>

        <tbody>
          {transactions.length > 0 ? (
            transactions.map((t) => (
              <tr key={t.transactionId}>
                <td>{t.transactionId}</td>
                <td>{formatVND(t.amount)}</td>
                <td className={`status ${t.status?.toLowerCase()}`}>
                  {translateStatus(t.status)}
                </td>
                <td>{translateType(t.type)}</td>
                <td>
                  {t.createdAt
                    ? new Date(t.createdAt).toLocaleString("vi-VN", {
                        hour12: false,
                      })
                    : "-"}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} className="no-data-cell">
                Không có dữ liệu giao dịch.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ThanhToanPage;
