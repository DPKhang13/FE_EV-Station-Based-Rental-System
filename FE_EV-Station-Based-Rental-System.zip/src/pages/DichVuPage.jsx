import React from 'react'

const DichVuPage = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default DichVuPage
